<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            ['name' => 'Ahmed Developer', 'email' => 'ahmed@example.com'],
            ['name' => 'Sara Ali', 'email' => 'sara@example.com'],
            ['name' => 'Omar Khaled', 'email' => 'omar@example.com'],
            ['name' => 'Lina Hasan', 'email' => 'lina@example.com'],
            ['name' => 'Mona Samir', 'email' => 'mona@example.com'],
        ];

        foreach ($users as $data) {
            User::updateOrCreate(
                ['email' => $data['email']],
                [
                    'name' => $data['name'],
                    'password' => Hash::make('password'),
                    'email_verified_at' => now(),
                ]
            );
        }
    }
}
