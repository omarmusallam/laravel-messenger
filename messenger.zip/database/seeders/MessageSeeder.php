<?php

namespace Database\Seeders;

use App\Models\Conversation;
use App\Models\Message;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MessageSeeder extends Seeder
{
    public function run()
    {
        $conversations = Conversation::with('participants')->orderBy('id')->get();

        foreach ($conversations as $conversation) {
            $participantIds = $conversation->participants->pluck('id')->values();
            if ($participantIds->count() < 2) {
                continue;
            }

            $messagesData = $this->messagesForConversation($conversation->id, $participantIds->all());
            $lastMessageId = null;

            foreach ($messagesData as $index => $data) {
                $createdAt = Carbon::now()->subHours(12)->addMinutes(($conversation->id * 20) + ($index * 7));

                $message = Message::create([
                    'conversation_id' => $conversation->id,
                    'user_id' => $data['sender_id'],
                    'type' => $data['type'] ?? 'text',
                    'body' => $data['body'],
                    'created_at' => $createdAt,
                    'updated_at' => $createdAt,
                ]);

                $recipientIds = collect($participantIds)->reject(fn ($id) => $id === $data['sender_id']);
                foreach ($recipientIds as $recipientId) {
                    DB::table('recipients')->insert([
                        'user_id' => $recipientId,
                        'message_id' => $message->id,
                        'read_at' => $data['read_all'] ?? false ? $createdAt->copy()->addMinutes(2) : null,
                        'deleted_at' => null,
                    ]);
                }

                $lastMessageId = $message->id;
            }

            $conversation->update(['last_message_id' => $lastMessageId]);
        }
    }

    private function messagesForConversation(int $conversationId, array $participantIds): array
    {
        $a = $participantIds[0];
        $b = $participantIds[1] ?? $participantIds[0];
        $c = $participantIds[2] ?? $participantIds[0];
        $d = $participantIds[3] ?? $participantIds[0];

        if ($conversationId === 1) {
            return [
                ['sender_id' => $a, 'body' => 'Hi Sara, welcome to the messenger demo.', 'read_all' => true],
                ['sender_id' => $b, 'body' => 'Thanks Ahmed. I am testing the conversation screen now.', 'read_all' => true],
                ['sender_id' => $a, 'body' => 'Great. Try sending a few messages and marking them as read.', 'read_all' => false],
            ];
        }

        if ($conversationId === 2) {
            return [
                ['sender_id' => $a, 'body' => 'Hey Omar, did you finish the API integration?', 'read_all' => true],
                ['sender_id' => $b, 'body' => 'Almost done. I still need to review the auth flow.', 'read_all' => false],
            ];
        }

        return [
            ['sender_id' => $a, 'body' => 'Welcome everyone to the Project Team group.', 'read_all' => true],
            ['sender_id' => $b, 'body' => 'Looks good. The chat layout is clean.', 'read_all' => true],
            ['sender_id' => $c, 'body' => 'I will test attachments and unread counters next.', 'read_all' => false],
            ['sender_id' => $d, 'body' => 'Perfect. We can demo this project after polishing the README.', 'read_all' => false],
        ];
    }
}
