<?php

namespace Database\Seeders;

use App\Models\Conversation;
use App\Models\User;
use Illuminate\Database\Seeder;

class ConversationSeeder extends Seeder
{
    public function run()
    {
        $users = User::orderBy('id')->get();

        if ($users->count() < 4) {
            return;
        }

        // Peer conversation: Ahmed <-> Sara
        $peer1 = Conversation::create([
            'user_id' => $users[0]->id,
            'type' => 'peer',
        ]);
        $peer1->participants()->attach([
            $users[0]->id => ['joined_at' => now()->subDays(4), 'role' => 'admin'],
            $users[1]->id => ['joined_at' => now()->subDays(4), 'role' => 'member'],
        ]);

        // Peer conversation: Ahmed <-> Omar
        $peer2 = Conversation::create([
            'user_id' => $users[0]->id,
            'type' => 'peer',
        ]);
        $peer2->participants()->attach([
            $users[0]->id => ['joined_at' => now()->subDays(3), 'role' => 'admin'],
            $users[2]->id => ['joined_at' => now()->subDays(3), 'role' => 'member'],
        ]);

        // Group conversation
        $group = Conversation::create([
            'user_id' => $users[0]->id,
            'label' => 'Project Team',
            'type' => 'group',
        ]);
        $group->participants()->attach([
            $users[0]->id => ['joined_at' => now()->subDays(2), 'role' => 'admin'],
            $users[1]->id => ['joined_at' => now()->subDays(2), 'role' => 'member'],
            $users[2]->id => ['joined_at' => now()->subDays(2), 'role' => 'member'],
            $users[3]->id => ['joined_at' => now()->subDays(2), 'role' => 'member'],
        ]);
    }
}
